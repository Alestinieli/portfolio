﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Генератор_миров
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            label6.Text = "";
            label7.Text = "";
            label8.Text = "";
            label9.Text = "";
            label10.Text = "";
            label14.Text = "";
            label12.Text = "";
            label16.Text = "";
            label6.Visible = true;
            label7.Visible = true;
            label8.Visible = true;
            label9.Visible = true;
            label10.Visible = true;
            label14.Visible = true;
            label12.Visible = true;
            label16.Visible = true;
            Random rand = new Random();
            int mat = 1 + rand.Next(10), z;
            label6.Text = mat.ToString();
            for (int i=0; i< mat; i++)
            {
                z = rand.Next(7) + 1;
                switch (z)
                {
                    case 1:
                        label12.Text += " горный,";
                        break;
                    case 2:
                        label12.Text += " равнинный,";
                        break;
                    case 3:
                        label12.Text += " пустынный,";
                        break;
                    case 4:
                        label12.Text += " вулканический,";
                        break;
                    case 5:
                        label12.Text += " лесной,";
                        break;
                    case 6:
                        label12.Text += " степной,";
                        break;
                    case 7:
                        label12.Text += " болотистый,";
                        break;
                    default:
                        break;
                }
            }
            label12.Text = label12.Text.Substring(0, label12.Text.Length - 1) + ".";
            int mag = rand.Next(2);
            if (mag == 0) label10.Text = "Нет";
            else label10.Text = "Да";
            Random rand1 = new Random();
            int[] mas = { 0, 0, 0, 0, 0, 0, 0, 0 };
            int k = 1 + rand.Next(8);
            bool flag = true, flag1;
            for (int i=1;i<= k;i++)
            {
                z = rand1.Next(8) + 1;
                do
                {
                    flag1 = true;
                    for (int j = 0; j < 8; j++)
                    {
                        if (mas[j] == z)
                        {
                            flag = false;
                            break;
                        }
                    }

                    if (flag == false)
                    {
                        z = rand1.Next(8) + 1;
                        flag = true;
                    }
                    else
                    {
                        mas[i-1] = z;
                        flag1 = false;
                    }
                } while (flag1 == true);
                switch (z)
                {
                    case 1:
                        label9.Text += " эльфы,";
                        break;
                    case 2:
                        label9.Text += " люди,";
                        break;
                    case 3:
                        label9.Text += " драконы,";
                        break;
                    case 4:
                        label9.Text += " дриады,";
                        break;
                    case 5:
                        label9.Text += " гномы,";
                        break;
                    case 6:
                        label9.Text += " фэйри,";
                        break;
                    case 7:
                        label9.Text += " оборотни,";
                        break;
                    case 8:
                        label9.Text += " дроу,";
                        break;
                    default:
                        break;
                }
            }
            label9.Text=label9.Text.Substring(0, label9.Text.Length - 1)+".";
            int stran = rand.Next(50) + 1;
            label8.Visible = false;
            label5.Visible = false;
            label7.Text = stran.ToString();
            int klimat = rand.Next(4) + 1;
            int[] mas1 = { 0, 0, 0, 0 };
            flag = true;
            for (int i = 1; i <= klimat; i++)
            {
                z = rand1.Next(4) + 1;
                do
                {
                    flag1 = true;
                    for (int j = 0; j < 4; j++)
                    {
                        if (mas1[j] == z)
                        {
                            flag = false;
                            break;
                        }
                    }

                    if (flag == false)
                    {
                        z = rand1.Next(4) + 1;
                        flag = true;
                    }
                    else
                    {
                        mas1[i - 1] = z;
                        flag1 = false;
                    }
                } while (flag1 == true);
                switch (z)
                {
                    case 1:
                        label14.Text += " экваториальный,";
                        break;
                    case 2:
                        label14.Text += " тропический,";
                        break;
                    case 3:
                        label14.Text += " умеренный,";
                        break;
                    case 4:
                        label14.Text += " арктический,";
                        break;
                    default:
                        break;
                }
            }
            label14.Text = label14.Text.Substring(0, label14.Text.Length - 1) + ".";
            int mir = rand.Next(2);
            if (mir == 0) label16.Text = "Нет";
            else label16.Text = "Да";
















            /*for (int i=1; i<= stran; i++)
            {
                z = rand1.Next(8) + 1;
                switch (z)
                {
                    case 1:
                        label8.Text += " абсолютная монархия,";
                        break;
                    case 2:
                        label8.Text += " сословно-представительная монархия ,";
                        break;
                    case 3:
                        label8.Text += " дуалистическая монархия,";
                        break;
                    case 4:
                        label8.Text += " парламентская монархия,";
                        break;
                    case 5:
                        label8.Text += " президентская республика,";
                        break;
                    case 6:
                        label8.Text += " парламентская республика,";
                        break;
                    case 7:
                        label8.Text += " смешанная республика,";
                        break;
                    case 8:
                        label8.Text += " Директория,";
                        break;
                    default:
                        break;
                }
            }
            label8.Text = label8.Text.Substring(0, label8.Text.Length - 1) + ".";*/
        }
    }
}
