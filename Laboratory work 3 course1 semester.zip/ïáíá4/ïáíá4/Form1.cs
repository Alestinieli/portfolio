﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лаба4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        struct koord
        {
            public float X;
            public float Y;
            public koord(float x, float y)
            {
                this.X = x;
                this.Y = y;
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int width = this.Width;
            int height = this.Height;
            Pen pen = new Pen(Color.Black); 
            koord middle = new koord(width / 2, height / 2);
            koord middle1, middle2;
            middle2.X = width /4;
            middle2.Y = middle.Y;
            middle1.X = width * 3 / 4;
            middle1.Y = middle.Y;
            //Оси диметрия
            e.Graphics.DrawLine(pen, middle1.X, middle1.Y, middle1.X, middle1.Y - 200); //"ось" z
            e.Graphics.DrawLine(pen, middle1.X, middle1.Y, middle1.X, middle1.Y + 200);
            
            e.Graphics.DrawLine(pen, middle1.X, middle1.Y, (float)(middle1.X + Math.Cos((double)(0.785398)) * 200), (float)(middle1.Y + Math.Sin((double)(0.785398)) * 200)); //"ось" x
            e.Graphics.DrawLine(pen, middle1.X, middle1.Y, (float)(middle1.X - Math.Cos((double)(0.785398)) * 200), (float)(middle1.Y - Math.Sin((double)(0.785398)) * 200));

            e.Graphics.DrawLine(pen, middle1.X, middle1.Y, middle1.X + 200, middle1.Y); //"ось" y
            e.Graphics.DrawLine(pen, middle1.X, middle1.Y, middle1.X - 200, middle1.Y);

            //оси изометрия
            double sin30 = 0.5, cos30 = Math.Cos((double)(0.5236)), sin270 = -0.5;
            e.Graphics.DrawLine(pen, middle2.X, middle2.Y, middle2.X, middle2.Y - 200); //"ось" z
            e.Graphics.DrawLine(pen, middle2.X, middle2.Y, middle2.X, middle2.Y + 200);

            e.Graphics.DrawLine(pen, middle2.X, middle2.Y, (float)(middle2.X + cos30 * 200), (float)(middle2.Y + sin30 * 200)); //"ось" x
            e.Graphics.DrawLine(pen, middle2.X, middle2.Y, (float)(middle2.X - cos30 * 200), (float)(middle2.Y - sin30 * 200));

            e.Graphics.DrawLine(pen, middle2.X, middle2.Y, (float)(middle2.X + cos30 * 200), (float)(middle2.Y + sin270 * 200)); //"ось" y
            e.Graphics.DrawLine(pen, middle2.X, middle2.Y, (float)(middle2.X - cos30 * 200), (float)(middle2.Y - sin270 * 200));
            pen.Width = 2;
            int a, b, h, m;
            a = 2;
            b = 2;
            h = 64;
            m = 40;
            int b_kv = b * b, a_kv = a * a, m_kv = m * m;
            double b1 = b * Math.Sqrt(h), a1 = a * Math.Sqrt(h);
            koord z = middle1, z1, z2, z3, z4, z5, z6;
            //Параболоид диметрия
            int i = 1;
            z = middle1;
            //Фрагмент параболы z=x^2/a^2
            while (z.Y > middle1.Y + Math.Sin((double)(0.785398)) * m_kv / a_kv - m_kv / a_kv)
            {
                z1.X = (float)(z.X - Math.Cos((double)(0.785398)) * i);
                z1.Y = (float)(z.Y - Math.Sin((double)(0.785398)) * i) - i * i / a_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            int j = i;
            z3 = z;
            i = 1;
            //парабола z=m^2/a^2-y^2/b^2
            while (z.Y < middle1.Y  + h)
            {
                z1.X = z.X - i;
                z1.Y = z.Y + i * i / b_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            z2 = z;
            z5 = z2;
            i = 1;
            z = z3;
            i = 1;
            while (z.Y < middle1.Y + h)
            {
                z1.X = z.X +  i;
                z1.Y = z.Y + i * i / b_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            z2 = z;
            z6 = z2;
            int k = i;
            i = 1;
            z = middle1;
            i = 1;
            z = middle1;
            //Фрагмент параболы z=x^2/a^2
            while (i<j)
            {
                z1.X = (float)(z.X + Math.Cos((double)(0.785398)) * i);
                z1.Y = (float)(z.Y + Math.Sin((double)(0.785398)) * i) - i * i / a_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            z3 = z;
            i = 1;
            //парабола z=m^2/a^2-y^2/b^2
            while (i<k)
            {
                z1.X = z.X - i;
                z1.Y = z.Y + i * i / b_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            z2 = z;
            i = 1;
            z = z5;
            //гипербола y^2/b1^2-x^2/a1^2=1
            while (z.Y < z2.Y)
            {
                z1.X = (float)((z.X + Math.Cos((double)(0.785398)) * i) + b1 * (float)(Math.Sqrt(1 + i * i / a1 / a1))/3);
                z1.Y = (float)(z.Y + Math.Sin((double)(0.785398)) * i) + (float)(i * 1.2);
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            i = 1;
            z = z3;
            i = 1;
            //парабола z=m^2/a^2-y^2/b^2
            while (i<k)
            {
                z1.X = z.X + i;
                z1.Y = z.Y + i * i / b_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            z2 = z;
            i = 1;
            //гипербола y^2/b1^2-x^2/a1^2=1
            while (z.X>z6.X)
            {
                z1.X = (float)((z.X - Math.Cos((double)(0.785398)) * i) - b1 * (float)(Math.Sqrt(1 + i * i / a1 / a1))/1.55);
                z1.Y = (float)(z.Y - Math.Sin((double)(0.785398)) * i) - i*3;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }


            //Параболоид изометрия
            i = 1;
            z = middle2;
            //Фрагмент параболы z=x^2/a^2
            while (z.Y > middle2.Y + sin30 * m_kv / a_kv - m_kv / a_kv)
            {
                z1.X = (float)(z.X - cos30 * i);
                z1.Y = (float)(z.Y - cos30 * i) - i * i / a_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
             j = i;
             z3 = z;
            i = 1;
            //парабола z=m^2/a^2-y^2/b^2
            while (z.Y < middle2.Y - sin270 * h + h && z.X < middle2.X - cos30 * h / 2)
            {
                z1.X = (float)(z.X - cos30 * i);
                z1.Y = (float)(z.Y - sin270 * i) + i * i / b_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            k = i;
            z2 = z;
            z5 = z2;
            z = z3;
            i = 1;
            while (z.Y < middle2.Y - sin30 * h + h && z.X < middle2.X + cos30 * h / 2)
            {
                z1.X = (float)(z.X + cos30 * i);
                z1.Y = (float)(z.Y - sin30 * i) + i * i / b_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            z2 = z;
            z6 = z2;
            i = 1;
            z = middle2;
            //Фрагмент параболы z=x^2/a^2
            while (i < j)
            {
                z1.X = (float)(z.X + cos30 * i);
                z1.Y = (float)(z.Y - sin270 * i) - i * i / a_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            z3 = z;
            i = 1;
            //парабола z=m^2/a^2-y^2/b^2
            while (i < k)
            {
                z1.X = (float)(z.X + cos30 * i);
                z1.Y = (float)(z.Y - sin30 * i) + i * i / b_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            z4 = z;
            z = z4;
            i = 1;
            //гипербола y^2/b1^2-x^2/a1^2=1
            while (z.X > z6.X)
            {
                z1.X = (float)((z.X - cos30 * i) - (float)(Math.Sqrt(b1 * b1 + b1 * b1 * i * i / a1 / a1)));
                z1.Y = (float)(z.Y - sin30 * i) - (float)(3.4) * i;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            i = 1;
            z = z3;
            //парабола z=m^2/a^2-y^2/b^2
            while (i < k)
            {
                z1.X = (float)(z.X - cos30 * i);
                z1.Y = (float)(z.Y - sin270 * i) + i * i / b_kv;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }
            z4 = z;
            i = 1;
            z = z5;
            //гипербола y^2/b1^2-x^2/a1^2=1
            while (z.X < z4.X)
            {
                z1.X = (float)((z.X + cos30 * i) + (float)(Math.Sqrt(b1 * b1 + b1 * b1 * i * i / a1 / a1)));
                z1.Y = (float)(z.Y + sin30 * i) + 3 * i;
                e.Graphics.DrawLine(pen, z.X, z.Y, z1.X, z1.Y);
                z = z1;
                i++;
            }

        }
        
    }
}
